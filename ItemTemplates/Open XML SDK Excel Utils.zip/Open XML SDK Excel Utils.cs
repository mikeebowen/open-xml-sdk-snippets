﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace OpenXmlSdkUtils
{
    public class ExcelUtils
    {
        // Given a document name and text, 
        // inserts a new worksheet and writes the text into a cell of the new worksheet.

        public static SpreadsheetDocument InsertText(SpreadsheetDocument spreadSheet, string text, string columnName, uint rowIndex, WorksheetPart? wsp)
        {
            if (string.IsNullOrEmpty(text))
            {
                throw new ArgumentNullException(nameof(text));
            }
            if (string.IsNullOrEmpty(columnName))
            {
                throw new ArgumentNullException(nameof(columnName));
            }
            if (string.IsNullOrEmpty(rowIndex.ToString()))
            {
                throw new ArgumentNullException(nameof(rowIndex));
            }

            // Get the SharedStringTablePart. If it does not exist, create a new one.
            SharedStringTablePart shareStringPart;
            if (spreadSheet != null && spreadSheet.WorkbookPart != null)
            {
                if (spreadSheet.WorkbookPart.GetPartsOfType<SharedStringTablePart>().Any())
                {
                    shareStringPart = spreadSheet.WorkbookPart.GetPartsOfType<SharedStringTablePart>().First();
                }
                else
                {
                    shareStringPart = spreadSheet.WorkbookPart.AddNewPart<SharedStringTablePart>();
                }
            }
            else
            {
                throw new ArgumentNullException(nameof(spreadSheet));
            }

            // Insert the text into the SharedStringTablePart.
            int index = InsertSharedStringItem(text, shareStringPart);

            WorksheetPart worksheetPart;
            // Insert a new worksheet if wsp is null.
            if (wsp == null)
            {
                worksheetPart = InsertWorksheet(spreadSheet.WorkbookPart);
            }
            else
            {
                worksheetPart = wsp;
            }

            // Insert cell into the worksheet.
            Cell cell = InsertCellInWorksheet(columnName, rowIndex, worksheetPart);

            // Set the value of the cell.
            cell.CellValue = new CellValue(index.ToString());
            cell.DataType = new EnumValue<CellValues>(CellValues.SharedString);

            worksheetPart.Worksheet.Save();

            if (spreadSheet != null)
            {
                return spreadSheet;
            }
            else
            {
                throw new ArgumentNullException(nameof(spreadSheet));
            }
        }

        // Given text and a SharedStringTablePart, creates a SharedStringItem with the specified text 
        // and inserts it into the SharedStringTablePart. If the item already exists, returns its index.
        public static int InsertSharedStringItem(string text, SharedStringTablePart shareStringPart)
        {
            // If the part does not contain a SharedStringTable, create one.
            if (shareStringPart.SharedStringTable == null)
            {
                shareStringPart.SharedStringTable = new SharedStringTable();
            }

            int i = 0;

            // Iterate through all the items in the SharedStringTable. If the text already exists, return its index.
            foreach (SharedStringItem item in shareStringPart.SharedStringTable.Elements<SharedStringItem>())
            {
                if (item.InnerText == text)
                {
                    return i;
                }

                i++;
            }

            // The text does not exist in the part. Create the SharedStringItem and return its index.
            shareStringPart.SharedStringTable.AppendChild(new SharedStringItem(new DocumentFormat.OpenXml.Spreadsheet.Text(text)));
            shareStringPart.SharedStringTable.Save();

            return i;
        }

        // Given a WorkbookPart, inserts a new worksheet.
        public static WorksheetPart InsertWorksheet(WorkbookPart workbookPart)
        {
            // Add a new WorksheetPart to the workbook.
            WorksheetPart newWorksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            newWorksheetPart.Worksheet = new Worksheet(new SheetData());
            newWorksheetPart.Worksheet.Save();

            if (workbookPart != null && workbookPart.Workbook != null)
            {
                Sheets? sheets = workbookPart.Workbook.GetFirstChild<Sheets>();

                if (sheets == null)
                {
                    sheets = new Sheets();
                    workbookPart.Workbook.AddChild(sheets);
                }
                string relationshipId = workbookPart.GetIdOfPart(newWorksheetPart);

                // Get a unique ID for the new sheet.
                uint sheetId = 1;

                if (sheets.Elements<Sheet>().Count() > 0)
                {
                    IEnumerable<Sheet> sheetElements = sheets.Elements<Sheet>();

                    foreach (Sheet el in sheetElements)
                    {
                        if (el != null && !string.IsNullOrEmpty(el.SheetId))
                        {
                            sheetId += el.SheetId.Value;
                        }
                    }
                }

                string sheetName = string.Concat("Sheet", sheetId);

                // Append the new worksheet and associate it with the workbook.
                Sheet sheet = new Sheet() { Id = relationshipId, SheetId = sheetId, Name = sheetName };
                sheets.Append(sheet);
                workbookPart.Workbook.Save();

                return newWorksheetPart;
            }
            else
            {
                throw new ArgumentNullException(nameof(workbookPart));
            }
        }

        // Given a column name, a row index, and a WorksheetPart, inserts a cell into the worksheet. 
        // If the cell already exists, returns it. 
        public static Cell InsertCellInWorksheet(string columnName, uint rowIndex, WorksheetPart worksheetPart)
        {
            if (worksheetPart != null)
            {
                Worksheet worksheet = worksheetPart.Worksheet ?? new Worksheet();

                SheetData? sheetData = worksheet.GetFirstChild<SheetData>();

                if (sheetData == null)
                {
                    sheetData = new SheetData();
                    worksheet.AddChild(sheetData);
                }

                string cellReference = columnName + rowIndex;

                // If the worksheet does not contain a row with the specified row index, insert one.
                Row row;
                if (sheetData.Elements<Row>().Where(r => !string.IsNullOrEmpty(r.RowIndex) && r.RowIndex == rowIndex).Count() != 0)
                {
                    row = sheetData.Elements<Row>().Where(r => !string.IsNullOrEmpty(r.RowIndex) && r.RowIndex == rowIndex).First();
                }
                else
                {
                    row = new Row() { RowIndex = rowIndex };
                    sheetData.Append(row);
                }

                // If a cell with the specified column name doesn’t exist, insert one.  
                if (row.Elements<Cell>().Where(c => !string.IsNullOrEmpty(c.CellReference) && c.CellReference.Value == columnName + rowIndex).Count() > 0)
                {
                    return row.Elements<Cell>().Where(c => !string.IsNullOrEmpty(c.CellReference) && c.CellReference.Value == cellReference).First();
                }
                else
                {
                    // Cells must be in sequential order according to CellReference. Determine where to insert the new cell.
                    Cell? refCell = null;

                    foreach (Cell cell in row.Elements<Cell>())
                    {
                        if (!string.IsNullOrEmpty(cell.CellReference) && string.Compare(cell.CellReference.Value, cellReference, true) > 0)
                        {
                            refCell = cell;
                            break;
                        }
                    }

                    if (refCell != null)
                    {
                        Cell newCell = new Cell() { CellReference = cellReference };
                        row.InsertBefore(newCell, refCell);

                        worksheet.Save();
                        return newCell;
                    }
                    else
                    {
                        throw new InvalidDataException();
                    }
                }
            }
            else
            {
                throw new ArgumentNullException(nameof(worksheetPart));
            }
        }

        public static Sheet? GetSheet(SpreadsheetDocument spreadsheetDocument, string sheetName)
        {
            IEnumerable<Sheet>? sheets = spreadsheetDocument.WorkbookPart?.Workbook.Descendants<Sheet>().Where(s => s.Name == sheetName);

            if (sheets != null && sheets.Count() > 0)
            {
                return sheets.FirstOrDefault();
            }

            return null;
        }
    }
}
